NANA DATA HUB — STARTER WEBSITE

Files:
- index.html: responsive static website with a WhatsApp order-enquiry form.
- This is a starter website only. It is not live, does not process payments, and does not automatically deliver data.

WhatsApp:
- The enquiry button is configured for the business number supplied in the chat.
- Confirm with your parent/guardian that this number is approved for public business use before publishing.

Before publishing:
1. Confirm the reseller supplier is legitimate and check its fees, delivery process, refund policy and support.
2. Replace Starter, Standard and Plus with exact supplier-confirmed MTN bundle sizes, prices and validity.
3. Have your parent/guardian review and manage any merchant/payment account. Do not share PINs, OTPs, passwords or secret API keys in chat or public website code.
4. Check whether nanadatahub.com is available and register it only with guardian approval. The domain has not been purchased.
5. Upload the website files to a static hosting service after review. The site is not yet online.

The site is an independent enquiry page and is not affiliated with MTN.
